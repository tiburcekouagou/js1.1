/**
 * Créer ici le projet bonus de calculatrice.
 */
